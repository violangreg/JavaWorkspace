// Sarah Jihye Han, 010183574, CECS277 Project Extra Credit
/**
 * imports from library
 */
import java.awt.*;
import java.util.*;
/**
 * Enemy class
 * @author Sarah Jihye Han
 */
public class Enemy extends Character {
	private Image image;
	private String imString;
	/**
	 * Enemy constructor,
	 * @param n, name
	 * @param q, quip
	 * @param h, hp
	 * @param l, level
	 * @param g, gold
	 * @param i, item
	 */
	public Enemy(String n, String q, int h, int l, int g, Item i, Point p, String im){
		super(n, q, h*2, l, g, p, 50, 50);
		item = i;
		imString = im;
		image = new Image((int)p.getX(), (int)p.getY(), im, null);
	}
	/**
	 * Abstract method attack overriding, attacks with random damage
	 */
	@Override
	public int attack(Character c) {
		Random rand = new Random();
		int randomNum;
		
		randomNum = rand.nextInt((2*getLevel() - 1+getLevel()) + 1) + 1;
		c.takeDamage(randomNum);
		return randomNum;
	}
	/**
	 * returns the item of this object
	 * @return retusn the item
	 */
	public Item getItem(){
		return item;
	}
	public String getImageString(){
		return imString;
	}
	public Image getImage(){
		return image;
	}
	/**
	 * private Item item
	 */
	private Item item;
	@Override
	public void draw(Graphics g, Point p, int w, int h) {
		image.paintComponent(g);
	}
}
