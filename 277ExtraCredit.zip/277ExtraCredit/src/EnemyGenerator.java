// Sarah Jihye Han, 010183574, CECS277 Project Extra Credit
/**
 * imports from library
 */
import java.awt.*;
import java.io.*;
import java.util.*;
/**
 * Enemy Generator class
 * @author Sarah Jihye Han
 */
public class EnemyGenerator {
	/**
	 * private ArrayList enemyList 
	 */
	private ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
	/**
	 * EnemyGenerator constructor, gets files from the EnemyList.txt file and put it in to the array
	 */
	public EnemyGenerator(){
		Item testItem = new Item("blank", 0);
		try{
		Scanner read = new Scanner(new File("EnemyList.txt"));
		do{
			read.useDelimiter(",");
			String line = read.nextLine();
			String[] tokens = line.split(",");
			                        //NAME     //QUIP      //HP                     //LV //G //ITEM
			Enemy enemy = new Enemy(tokens[0], tokens[1], Integer.parseInt(tokens[2]), 0, 0, testItem, new Point(0,0), tokens[0] + ".png");
			
			enemyList.add(enemy);
		}while(read.hasNext());
		read.close();
		}catch(FileNotFoundException fnf){
			System.out.println("FNF");
		}	
	}
	/**
	 * Generate a Enemy object, generate randomly
	 * @param level
	 * @return enemy
	 */
	public Enemy generateEnemy(int level){
		Enemy enemy = null;
		Item monsterItem = null;
		int randomMob = 0;
		int gold = 0;
		Random rand = new Random();
		ItemGenerator itemGen = new ItemGenerator();
		monsterItem = itemGen.generateItem();

		Point p = new Point(0,0);
		int randomPosition = rand.nextInt(8) + 1;
		if(randomPosition == 1){
			p.x = 586;
			p.y = 242;
		}
		else if(randomPosition == 2){
			p.x = 651;
			p.y = 387;
		}
		else if(randomPosition == 3){
			p.x = 651;
			p.y = 240;
		}
		else if(randomPosition == 4){
			p.x = 727;
			p.y = 239;
		}
		else if(randomPosition == 5){
			p.x = 723;
			p.y = 385;
		}
		else if(randomPosition == 6){
			p.x = 804;
			p.y = 241;
		}
		else if(randomPosition == 7){
			p.x = 802;
			p.y = 309;
		}
		else if(randomPosition == 8){
			p.x = 800;
			p.y = 385;
		}
		
		if(level == 1){
			rand = new Random();
			randomMob = rand.nextInt((3 - 1) + 1) + 1;
			gold = rand.nextInt((10 - 0) + 1) + 0; 
			if(randomMob == 1) randomMob = 5;
			else if(randomMob == 2) randomMob = 2;
			else randomMob = 6;
			enemy = new Enemy(enemyList.get(randomMob).getName(), enemyList.get(randomMob).getQuip(), 
					enemyList.get(randomMob).getHp(), 1, gold, monsterItem, p, enemyList.get(randomMob).getImageString());
		}
		else if(level == 2){
			rand = new Random();
			randomMob = rand.nextInt((3 - 1) + 1) + 1; 
			gold = rand.nextInt((20 - 0) + 1) + 0;
			if(randomMob == 1) randomMob = 4; 
			else if(randomMob == 2) randomMob = 0;
			else randomMob = 1;
			enemy = new Enemy(enemyList.get(randomMob).getName(), enemyList.get(randomMob).getQuip(),
					enemyList.get(randomMob).getHp()*2, 2, gold, monsterItem, p, enemyList.get(randomMob).getImageString());
			
		}
		else{
			rand = new Random();
			randomMob = rand.nextInt((3 - 1) + 1) + 1; 
			gold = rand.nextInt((30 - 0) + 1) + 0;
			if(randomMob == 1) randomMob = 1; 
			else if(randomMob == 2) randomMob = 3; 
			else randomMob = 7; 
			enemy = new Enemy(enemyList.get(randomMob).getName(), enemyList.get(randomMob).getQuip(),
					enemyList.get(randomMob).getHp()*2, 3, gold, monsterItem, p, enemyList.get(randomMob).getImageString());
		}
	
		return enemy;
	}
}
