// Sarah Jihye Han, 010183574, CECS277 Project Extra Credit
/**
 * imports from library
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
/**
 * Hero class, Serializable 
 * @author Sarah Jihye Han
 */
@SuppressWarnings("serial")
public class Hero extends Character implements Serializable {
	private Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	private int screen_width = (int) screen.getWidth();
	private int screen_height = (int) screen.getHeight();
	private int window_width = screen_width - screen_height/2;
	private int window_height = screen_height - screen_width/10;
	/**
	 * private items array
	 */
	private ArrayList<Item> items = new ArrayList<Item>();
	private BufferedImage heroRight, heroLeft, heroBack;
	private int direction;
	/**
	 * Hero class constructor
	 * @param n
	 * @param q
	 * @param start
	 */
	public Hero(String n, String q, Point p, int dir){
		super(n, q, 162, 1, 0, p, 40, 40);
		direction = dir;
		
		try {
			heroRight = ImageIO.read(new File("shannonRight.png"));
			heroLeft = ImageIO.read(new File("shannonLeft.png"));
			heroBack = ImageIO.read(new File("shannonBack.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * getDirections gets direction
	 * @return direction
	 */
	public int getDirection(){
		return direction;
	}
	/**
	 * setDirection sets the direction
	 * @param d
	 */
	public void setDirection(int d){
		direction = d;
	}
	/**
	 * returns Array of items
	 * @return items array
	 */
	public ArrayList<Item> getItems(){
		return items;
	}
	/**
	 * picks up items
	 * @param i
	 * @return true for > 5
	 */
	public boolean pickUpItem(Item i){
		if(items.size() > 5){
			return true;
		}else{
			items.add(i);
			return false;
		}
	}
	/**
	 * remove item
	 * @param i
	 */
	public void removeItem(Item i){
		items.remove(i);
	}
	/**
	 * remove items 
	 * @param index
	 */
	public void removeItem(int index){
		items.remove(index);
	}
	/**
	 * overriding attack method param c
	 * @param c, character
	 */
	@Override
	public int attack(Character c) {
		Random rand = new Random();
		int randomNum;
		
		randomNum = rand.nextInt((3*getLevel() - (1+getLevel())) + 1) + (1+getLevel());
		c.takeDamage(randomNum);
		return randomNum;
	}
	
	public void move(){
		switch(direction){
			case 1:this.setLocation(0, -70);
				break;
			case 2:this.setLocation(70, 0);
				break;
			case 3:this.setLocation(0, 70);
				break;
			case 4:this.setLocation(-70, 0);
				break;
		}
	}
	
	@Override
	public void draw(Graphics g, Point p, int w, int h) {
		// hero's hp
		g.setColor(Color.RED);
		g.fillRect(window_width/2 - 340, window_height/2 - 152, this.getHp(), 15);
		
		switch(direction){
		case 1: g.drawImage(heroBack,(int) p.getX(), (int) p.getY(), null);
			break;
		case 2: g.drawImage(heroRight, (int) p.getX(), (int) p.getY(), null);
			break;
		case 3: g.drawImage(heroRight, (int) p.getX(), (int) p.getY(), null);
			break;
		case 4: g.drawImage(heroLeft,(int) p.getX(), (int) p.getY(), null);
			break;
		}
	}
}
