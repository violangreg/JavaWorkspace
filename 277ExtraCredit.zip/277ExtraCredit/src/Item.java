// Sarah Jihye Han, 010183574, CECS277 Project Extra Credit
/**
 * imports from library
 */
import java.awt.Graphics;
import java.io.Serializable;
import java.util.Random;
/**
 * Item class, Serializable
 * @author Sarah Jihye Hans
 */
public class Item implements Serializable{
	private Image image;
	/**
	 * Item constructor
	 * @param n, name of item
	 * @param v, value of item
	 */
	public Item(String n, int v){
		name = n;
		goldValue = v;
		
		int x, y;
		x = y = 0;
		Random r = new Random();
		int randomPosition = r.nextInt(3) + 1;
		if(randomPosition == 1){
			x = 652;
			y = 167;
		}
		else if(randomPosition == 2){ 
			x = 723;
			y = 313;
		}
		else if(randomPosition == 3){
			x = 586;
			y = 171;
		}
		
		if(n.equals("Health Potion")){
			image = new Image(x, y, "potion.png", null);
		}
		else{
			image = new Image(x, y, "Items.png", null);
		}
	}
	/**
	 * returns the name of the item
	 * @return name of item
	 */
	public String getName(){
		return name;
	}
	/**
	 * returns the value of the item
	 * @return value of item
	 */
	public int getValue(){
		return goldValue;
	}
	public Image getImage(){
		return image;
	}
	/**
	 * private String name of object
	 */
	private String name;
	/**
	 * private int goldValue of object
	 */
	private int goldValue;
	
	public void draw(Graphics g){
		image.paintComponent(g);
	}
}
