// Sarah Jihye Han, 010183574, CECS277 Project Extra Credit
/**
 * imports from library
 */
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;
/**
 * Character class
 * @author Sarah Jihye Han
 */
public abstract class Character implements Serializable{
	/**
	 * private String name and quip of object
	 */
	private String name, quip;
	/**
	 * private int level, hp, and gold of object
	 */
	private int level, hp, gold;
	/**
	 * private Rectangle location of object
	 */
	private Rectangle location;
	/**
	 * Character constructor
	 * @param n, name
	 * @param q, quip
	 * @param h, hp
	 * @param l, level
	 * @param g, gold
	 */
	public Character(String n, String q, int h, int l, int g, Point p, int w, int ht){
		name = n;
		quip = q;
		hp = h;
		level = l;
		gold = g;
		location = new Rectangle((int)p.getX(), (int)p.getY(), w, ht);
	}
	/**
	 * abstract attack method
	 * @param c, character that is being attack
	 */
	public abstract int attack(Character c);
	/**
	 * returns the name of character 
	 * @return name
	 */
	public String getName(){
		return name;
	}
	/**
	 * returns quip of character
	 * @return quip
	 */
	public String getQuip(){
		return quip;
	}
	/**
	 * returns hp character
	 * @return hp
	 */
	public int getHp(){
		return hp;
	}
	/**
	 * returns level of character
	 * @return level
	 */
	public int getLevel(){
		return level;
	}
	/**
	 * returns the gold of character
	 * @return gold
	 */
	public int getGold(){
		return gold;
	}
	/**
	 * increase level of character
	 */
	public void increaseLevel(){
		++level;
	}
	/**
	 * heal character
	 * @param h
	 */
	public void heal(int h){
		hp += h;
	}
	/**
	 * character takes damage
	 * @param h, damage
	 */
	public void takeDamage(int h){
		hp -= h;
	}
	/**
	 * collects gold
	 * @param g
	 */
	public void collectGold(int g){
		gold += g;
	}	
	public Point getLocation(){
		return location.getLocation();
	}
	/**
	 * getBounds gets the Rectangle of the object (used for collision)
	 * @return Rectangle of object
	 */
	public Rectangle getBounds(){
		return location;
	}
	/**
	 * getWidth gets the width of the object
	 * @return width of the object
	 */
	public int getWidth(){
		return (int) location.getWidth();
	}
	/**
	 * getHeight gets the height of the object
	 * @return the height of the object
	 */
	public int getHeight(){
		return (int) location.getHeight();
	}
	/**
	 * isDead returns true if the object has equal or less than 0 hp, otherwise false
	 * @return true if the object has equal or less than 0 hp
	 */
	public boolean isDead(){
		boolean dead = false;
		if(hp <= 0) dead = true;
		return dead;
	}
	/**
	 * setWidth sets the width of the object
	 * @param w
	 */
	public void setWidth(int w){
		location.width = w;
	}
	/**
	 * setHeight sets the height of the object
	 * @param h
	 */
	public void setHeight(int h){
		location.height = h;
	}
	public void setLocation(int x, int y){
		Point p = new Point((int)this.getLocation().getX() + x,(int)this.getLocation().getY() + y);
		location.setLocation(p);
	}
	public void setPosition(Point p){
		location.setLocation(p);
	}
	/**
	 * update draws
	 * @param g
	 */
	public void update(Graphics g){
		draw(g, getLocation(), getWidth(), getHeight());
	}
	public abstract void draw(Graphics g, Point p, int w, int h);
}
