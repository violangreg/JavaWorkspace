/**
 * Job class is for constructing a Job object to be used in the heap. It has a task name and due date, they both have a 
 * get method. This implements Comparable to override compareTo for comparing in the heap. It also overrides toString for
 * displaying.
 * @author Greg Violan, 011706641
 *
 */
public class Job implements Comparable<Job>{
	/**
	 * Job constructor
	 * @param n, name of job
	 * @param d, date of job
	 */
	public Job(String n, String d){
		taskName = n;
		dueDate = d;
	}
	/**
	 * Gets the name of the job
	 * @return taskName, name of job
	 */
	public String getName(){
		return taskName;
	}
	/**
	 * Gets the date of the job
	 * @return dueDate, date of job
	 */
	public String getDate(){
		return dueDate;
	}
	/**
	 * Overrides compareTo, compares the date and time of the job
	 * @param j, the job to compare to
	 * @return compare, an integer used by comparing in the heap
	 */
	@Override
	public int compareTo(Job j) {
		int compare = 0;
		
		String[] thisTokens = this.dueDate.split("/"); // tokens of task date
		String[] thisTokens2 = thisTokens[2].split(" "); // tokens of task year
		String[] thisTokens3 = thisTokens2[1].split(":"); // tokens of task time

		String thisDateStr = thisTokens[0] + thisTokens[1];
		int thisDate = Integer.parseInt(thisDateStr);
		
		String thisTimeStr = thisTokens2[0] + thisTokens3[0] + thisTokens3[1];
		int thisTime = Integer.parseInt(thisTimeStr);
		
		
		String[] jTokens = j.dueDate.split("/"); // tokens of task date
		String[] jTokens2 = jTokens[2].split(" "); // tokens of task year
		String[] jTokens3 = jTokens2[1].split(":"); // tokens of task time
		
		String jDateStr = jTokens[0] + jTokens[1];
		int jDate = Integer.parseInt(jDateStr);
		
		String jTimeStr = jTokens2[0] + jTokens3[0] + jTokens3[1];
		int jTime = Integer.parseInt(jTimeStr);
		
		if(thisDate == jDate && thisTime == jTime){
			compare = 0;
			if(this.taskName.charAt(0) > j.taskName.charAt(0)){
				compare = -1;
			}
			else compare = 1;
		}
		else if(thisDate == jDate && thisTime < jTime){
			compare = 1;
		}
		else if(thisDate == jDate && thisTime > jTime){
			compare = -1;
		}
		else if(thisDate < jDate && thisTime == jTime){
			compare = 1;
		}
		else if(thisDate > jDate && thisTime == jTime){
			compare = -1;
		}
		else if(thisDate < jDate && thisTime < jTime){
			compare = 1;
		}
		else if(thisDate > jDate && thisTime > jTime){
			compare = -1;
		}
		else if(thisDate < jDate && thisTime > jTime){		
			compare = -1;
		}
		else if(thisDate > jDate && thisTime < jTime){
			compare = 1;
		}
		
		return compare; // -1 if argument is before, 1 if argument is after
	}
	/**
	 * Overrides toString for easier display
	 * @return taskName, name of job
	 * @return dueDate, date of job
	 */
	@Override
	public String toString(){
		return taskName + " " + dueDate; 
	}
	/**
	 * Name of the job
	 */
	private String taskName;
	/**
	 * Date of the job
	 */
	private String dueDate;
}
