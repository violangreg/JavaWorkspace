/**
 * Healable interface, used for additional methods
 * @author Greg
 *
 */
public interface Healable {
	/**
	 * used to for Overriding this to implented classes
	 * @param hp, passes in the hp's object
	 */
	public void heal(int hp);
}
